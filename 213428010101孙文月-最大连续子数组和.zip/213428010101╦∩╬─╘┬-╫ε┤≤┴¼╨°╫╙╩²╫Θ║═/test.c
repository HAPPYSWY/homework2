#define N 21000
#include<stdio.h> 
#include <math.h>

int find(int a[], int n);
int max(int a, int b);

int max(int a, int b)
{
	if (a >= b)
	{
		return a;
	}
	else
	{
		return b;
	}
}


int find(int a[], int n)
{
	int dp[N];
	dp[0] = a[0];
	int maxx = a[0];
	for (int i = 1; i < n; i++)
	{
		dp[i] = max(dp[i - 1] + a[i], a[i]);
		if (maxx < dp[i])
		{
			maxx = dp[i];
		}
	}
	return maxx;
}
int main()
{
	int a[N], n;
	printf("���������:");
	scanf_s("%d", &n);
	printf("��������ֵ:");
	for (int i = 0; i < n; i++)
		scanf_s("%d", &a[i]);
	int maxx = find(a, n);
	printf("���Ϊ:");
	printf("%d", maxx);
	return 0;
}


